package org.cap.loginRest.service;

import java.util.List;

import org.cap.loginRest.dao.LoginDao;
import org.cap.loginRest.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("loginService")
public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginDao loginDao;
	
	public void save(Customer customer) {
		
		loginDao.save(customer);
	}

	@Override
	public List<Customer> getAll() {
	
		return loginDao.findAll();
	}

}
