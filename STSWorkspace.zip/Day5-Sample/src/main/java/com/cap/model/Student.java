package com.cap.model;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

public class Student {
@Id
@GeneratedValue
private int studentId;
@NotEmpty(message="Please Enter the name")
private String studentName;
private String location;
public int getStudentId() {
	return studentId;
}
public void setStudentId(int studentId) {
	this.studentId = studentId;
}
public String getStudentName() {
	return studentName;
}
public void setStudentName(String studentName) {
	this.studentName = studentName;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
@Override
public String toString() {
	return "Student [studentId=" + studentId + ", studentName=" + studentName + ", location=" + location + "]";
}
public Student(int studentId, String studentName, String location) {
	super();
	this.studentId = studentId;
	this.studentName = studentName;
	this.location = location;
}
public Student() {
	super();
	
}

}
