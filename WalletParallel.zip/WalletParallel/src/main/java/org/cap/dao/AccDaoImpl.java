package org.cap.dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import javax.transaction.Transaction;
import javax.transaction.Transactional;

import org.cap.model.Account;
import org.cap.model.CustTransaction;
import org.springframework.stereotype.Repository;

@Repository("accountDao")
public class AccDaoImpl implements AccDao {

	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager em;
	
	@Override
	@org.springframework.transaction.annotation.Transactional
	public void createAccount(Account account) {
		Query query= em.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		em.persist(account);
		
	}

	@Override
	@org.springframework.transaction.annotation.Transactional(readOnly=true)
	public List<Account> getAllAccounts(int customerId) {
		Query query= em.createQuery("from Account  where customer.customerId=:custoId");
			
			query.setParameter("custoId", customerId);
			
			//Query query2=em.createQuery("from CustTransaction tx where tx.CustomerLogin.customerId=:custId");
			
			//query2.setParameter("custId", customerId);
			List<Account> accounts= query.getResultList();
			
			//List<Transaction> transactions=query2.getResultList();
			return accounts;
	}

	@Override
	@org.springframework.transaction.annotation.Transactional(readOnly=true)
	public Map<Account, Double> getAmoutCrDe(String strQuery, int customerId) {
		Query query2=em
				.createQuery(strQuery);
		
		query2.setParameter("custId", customerId);
		
		List<CustTransaction> transactions=query2.getResultList();
		Map<Account, Double> map=
		transactions.stream()
				.collect(
				Collectors.groupingBy(CustTransaction::getFromAccount,
					Collectors.summingDouble(CustTransaction::getAmount)));
		return map;
	}

	@Override
	public Account findAccount(long accNo) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accNo);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

	@Override
	public void addTransaction(CustTransaction transaction1) {
		System.out.println("Transaction complete............");
		em.persist(transaction1);
	}

	

	@Override
	public List<CustTransaction> getTransactions(int customerId) {
		Query query= em.createQuery("from CustTransaction tx where tx.customer.customerId=:custo");
		query.setParameter("custo", customerId);
			List<CustTransaction> transaction= query.getResultList();
		for (CustTransaction transaction2 : transaction) {
			System.out.println(transaction2);
		}
		
		return transaction;
	}

	@Override
	public Account getAccount(long accNo) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accNo);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

	@Override
	public Account getAccount1(long accNo1) {
		Query query= em.createQuery("from Account where accountNo=:accno");
		query.setParameter("accno", accNo1);
		List<Account> accounts= query.getResultList();
		return accounts.get(0);
	}

	@Override
	public void fundTransfer(CustTransaction transaction) {
		em.persist(transaction);
		
	}

	@Override
	public List<Account> getAllToAccounts(Integer customerId) {
		Query query=em.createQuery("from Account acc where acc.customer.customerId!=:custId");
		query.setParameter("custId", customerId);
		
		List<Account> accounts=query.getResultList();
		
		return accounts;
	}

	@Override
	public List<CustTransaction> getDatedTransactions(Integer id, Date d1, Date d2) {
		Calendar cal = Calendar.getInstance();
	    cal.setTime(d2);
	    cal.add(Calendar.DATE, 1); //minus number would decrement the days
	    Date d3= cal.getTime();
		Query query= em.createQuery("from Transaction tx where tx.customer.customerId=? and transactionDate between ? and ?");
		query.setParameter(0, id);
		query.setParameter(1,d1);
		query.setParameter(2,d3);
		
		List<CustTransaction> accounts= query.getResultList();
		for (CustTransaction account : accounts) {
			System.out.println(account);
		}
		
		
		return accounts; 


	}
	

	



}




