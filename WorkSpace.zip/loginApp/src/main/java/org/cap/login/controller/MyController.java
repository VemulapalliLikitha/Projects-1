package org.cap.login.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.cap.login.model.Customer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

@Controller
public class MyController  {
	
	

	@RequestMapping("/log")
	public String Details(ModelMap map) {
		
		
		return "login";
	}

	@PostMapping("/login")
	public String showDetails(ModelMap map, 
			@RequestParam("email") String email,
			@RequestParam("password") String password,
			HttpSession session) {
	
		session.setAttribute("email", email);
		session.setAttribute("pass", password);
		return "ChangePassword";
	}
	
	@RequestMapping("/ChangePassword")
	public String changePassword(ModelMap map,  HttpSession session) {
		
		if(session.isNew())
			return "login";
	 
	    
		return "ChangePassword";
	}
}
