package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.CustomerLogin;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Repository("loginDao")
@javax.transaction.Transactional
public class WalletDaoImpl implements WalletDao {
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager em;
	
	@Override
	public boolean validateLogin(int customerId, String custPwd) {
		Query query= em.createQuery("from CustomerLogin where customerId=? and customerPwd=?");
		query.setParameter(0, customerId);
		query.setParameter(1, custPwd);
		
		List<CustomerLogin> customers= query.getResultList();
		if(!customers.isEmpty())
			return true;
		return false;
	}

	@Override
	public String getCustomerName(int customerId) {
		Query query
		= em.createQuery("select cust.firstName from CustomerLogin cust where cust.customerId=:custId");
	query.setParameter("custId", customerId);
	List<String> customers= query.getResultList();
	
		return customers.get(0);
	}

	@Override
	public CustomerLogin findCustomer(int customerId) {
		
		CustomerLogin customer= em.find(CustomerLogin.class, customerId);
		
		return customer;
	}


	
}

/*@Override
public void saveAccount(Account account) {
	em.persist(account);
}

@Override
public List<Account> getAllAccounts(int customerId) {
	Query query=em.createQuery("select a from Account a where a.accountType=:uname");
    query.setParameter("uname", "rd");
    List<Account> account=query.getResultList();
    return account;
}

@Override
public Account find(int customerId) {
Account acc= em.find(Account.class, customerId);
	
	return acc;
}*/
