package com.cap.dao;

import java.util.List;

import com.cap.model.Student;

public interface StudentDAO {
public List<Student> getStudents();
}
