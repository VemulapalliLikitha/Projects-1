package org.cap.service;

import java.util.List;

import org.cap.modal.Pilot;

public interface PilotService {

	public void save(Pilot pilot);
	public List<Pilot> getall();
	public void delete(Integer pilotId);
	public void update(Pilot pilot);
	public Pilot findPilot(Integer pilotId);
}
