package com.cg.walletxyz.dao;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;

import com.cg.walletxyz.bean.Customer;
import com.cg.walletxyz.bean.Transactions;
import com.cg.walletxyz.bean.Wallet;
import com.cg.walletxyz.exception.WalletException;
public class WalletDaoImpl implements WalletDao {
	static HashMap<Integer,Customer> custmap=new HashMap<Integer,Customer>();
	static HashMap<Integer, Wallet> walletmap=new HashMap<Integer,Wallet>();
	static Map<String, Transactions> transactions=new HashMap<String, Transactions>();
	static Transactions transaction=new Transactions();
	
	@Override
	public int createAccount(Customer customer) throws WalletException {

	try {
			if(custmap.size()==0)
			{
				customer.setId(1001);
			}
			else {
				Optional<Integer> id=custmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int custid=id.get()+1;
				customer.setId(custid);
			}
			custmap.put(customer.getId(), customer);
			return customer.getId();
			
		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
	}

	@Override
	public int assignAccount(String type) throws WalletException {
		Wallet wallet=new Wallet();
		double balAmt=0;

		try {
			if(walletmap.size()==0)
			{
				wallet.setAccountno(5001);
				wallet.setBalance(balAmt);
			}
			else {
				Optional <Integer> account=walletmap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int accno=account.get()+1;
				wallet.setAccountno(accno);
				wallet.setBalance(balAmt);
			}
			
			walletmap.put(wallet.getAccountno(), wallet);

		}
		catch(Exception ex)
		{
			throw new WalletException(ex.getMessage());
		}
		return wallet.getAccountno();
	}

	@Override
	public double showBalance(int accno) throws WalletException {

		Wallet value=new Wallet();
		double bal=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					//System.out.println("ghcf");
					bal=value.getBalance();
					//System.out.println("jhjhvf");
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return bal;
		
	}

	@Override
	public double deposit(int accno, double amount) throws WalletException {

		Wallet value=new Wallet();
		double famount=0;		//final amount
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()+amount;
					value.setBalance(famount);
					String accNoInStr=String.valueOf(accno);
					Transactions transaction=new Transactions();
					transaction.setAccNo(accNoInStr);
					transaction.setTransactionType("Deposit");
					transaction.setAmount(amount);
					transaction.setBal(famount);
					transactions.put(accNoInStr,transaction);
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return famount;
	}

	@Override
	public int withdraw(int accno, double amount) throws WalletException {
		Wallet value=new Wallet();
		double famount=0;
		int status=0;
		try {
			if(!walletmap.containsKey(accno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value=walletmap.get(accno);
					famount=value.getBalance()-amount;
					value.setBalance(famount);
					String accNoInStr=String.valueOf(accno);
					Transactions transaction=new Transactions();
					transaction.setAccNo(accNoInStr);
					transaction.setTransactionType("Withdraw");
					transaction.setAmount(amount);
					transaction.setBal(famount);
					transactions.put(accNoInStr,transaction);
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	}

	@Override
	public int fundTransfer(int frommAccno, int tooAccno, double amount) throws WalletException {
		
		Wallet value1=new Wallet();	
		Wallet value2=new Wallet();

		
		double fromfinalamount=0;
		double tofinalamount=0;
		int status=0;
	
		try {
			if(!walletmap.containsKey(frommAccno) && !walletmap.containsKey(tooAccno))
			{
				throw new WalletException("Invalid Account number..!");
			}
			else {
					value1=walletmap.get(frommAccno);
					value2=walletmap.get(tooAccno);

					fromfinalamount=value1.getBalance()-amount;
					value1.setBalance(fromfinalamount);
					
					tofinalamount=value2.getBalance()+amount;
					value2.setBalance(tofinalamount);
					
					String frommAccnoStr=String.valueOf(frommAccno);
					
					Transactions transaction1=new Transactions();
					transaction1.setAccNo(frommAccnoStr);
					transaction1.setTransactionType("Debited");
					transaction1.setAmount(amount);
					transaction1.setBal(fromfinalamount);
					transactions.put(frommAccnoStr,transaction1);
					
					String tooAccnoStr=String.valueOf(tooAccno);
					
					Transactions transaction2=new Transactions();
					transaction2.setAccNo(tooAccnoStr);
					transaction2.setTransactionType("Credited");
					transaction2.setAmount(amount);
					transaction2.setBal(tofinalamount);
					transactions.put(tooAccnoStr,transaction2);
					
					status=1;
				}

		}
		catch(Exception ex)
		{
			System.out.println("Error occured:"+ex.getMessage());
		}
		return status;
	
	}

	@Override
	public Transactions printTransactions(String accno) throws WalletException {
		try {
			Map<Integer, Transactions> transactionmap=new HashMap<Integer,Transactions>();
			Transactions transaction=transactions.get(accno);
			
			if(transaction==null) {
				throw new WalletException("Customer with account no "+accno+"not available");
			}
			/*else {
				Iterator<Transactions> itr=transactions.iterator();
				while(itr.hasNext()) {
					
				}
			}*/
			return transaction;
		}catch (Exception e) {
			throw new WalletException(e.getMessage());
		}
		
	}
}
