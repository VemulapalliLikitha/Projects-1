package org.cap.dao;

public class WalletDaoImpl implements WalletDao {

}
