function validateForm() {
	alert("hello");
}