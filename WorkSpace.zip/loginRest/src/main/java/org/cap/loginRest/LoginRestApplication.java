package org.cap.loginRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan({"org.cap.loginRest.controller","org.cap.loginRest.service"})
@EntityScan("org.cap.loginRest.model")
@EnableJpaRepositories("org.cap.loginRest.dao")
public class LoginRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginRestApplication.class, args);
	}
}
