package org.cap.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class CustTransaction {
@Id

private int cId;
private int transactionId;
private Date transactionDate;
private String transactionType; //credit/debit
private long fromAccNo;
private long toAccNo;
private String description;
private double amount;
private String transactionStatus;
public CustTransaction() {
}
@Override
public String toString() {
	return "CustTransaction [cusId=" + cId + ", transactionId=" + transactionId + ", transactionDate="
			+ transactionDate + ", transactionType=" + transactionType + ", fromAccNo=" + fromAccNo + ", toAccNo="
			+ toAccNo + ", description=" + description + ", amount=" + amount + ", transactionStatus="
			+ transactionStatus + "]";
}
public int getCusId() {
	return cId;
}
public void setCusId(int cusId) {
	this.cId = cusId;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public Date getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(Date transactionDate) {
	this.transactionDate = transactionDate;
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
public long getFromAccNo() {
	return fromAccNo;
}
public void setFromAccNo(long fromAccNo) {
	this.fromAccNo = fromAccNo;
}
public long getToAccNo() {
	return toAccNo;
}
public void setToAccNo(long toAccNo) {
	this.toAccNo = toAccNo;
}
public String getDescription() {
	return description;
}
public void setDescription(String description) {
	this.description = description;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public String getTransactionStatus() {
	return transactionStatus;
}
public void setTransactionStatus(String transactionStatus) {
	this.transactionStatus = transactionStatus;
}


}
