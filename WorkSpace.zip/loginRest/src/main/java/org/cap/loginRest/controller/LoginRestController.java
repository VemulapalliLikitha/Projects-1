package org.cap.loginRest.controller;

import java.util.List;

import org.cap.loginRest.model.Customer;
import org.cap.loginRest.service.LoginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class LoginRestController {
	@Autowired
	private LoginService loginService;
	private Customer customer;
	
	@PostMapping("/login")
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer,
			@RequestParam("password2") String password2,
			@RequestParam("password3") String password3
			){
		if(password2.equals(password3))
			
		loginService.save(customer);
		
		return new ResponseEntity<Customer>(customer,HttpStatus.OK);
	}
	
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllPilots(){
		List<Customer> customers= loginService.getAll();
		if(customers.isEmpty()||customers==null)
			return new ResponseEntity
				("Sorry! Pilot details not available!",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Customer>>(customers,HttpStatus.OK);
	}

}
