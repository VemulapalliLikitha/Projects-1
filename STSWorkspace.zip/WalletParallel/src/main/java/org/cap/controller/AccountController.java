package org.cap.controller;

import java.util.List;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
@Controller
public class AccountController {

@RequestMapping("/CreateAccount")
public String showCreateAccountPage() {
	return "createAccount";
}

@RequestMapping("/ShowBalance")
public String showBalancePage() {
	return "showBalance";
}
@RequestMapping("/Deposit")
public String showDepositPage() {
	return "deposit";
}

@RequestMapping("/Withdraw")
public String showWithdrawPage() {
	return "withdraw";
}

@RequestMapping("/FundTransfer")
public String showFundTransferPage() {
	return "fundTransfer";
}

@RequestMapping("/PrintTransactions")
public String showPrintTransactionsPage() {
	return "printTransactions";
}

@RequestMapping("/Logout")
public String logout() {
	return "redirect:/";
} 


@RequestMapping("/Login")
public String validateLogin(ModelMap map, @RequestParam("username")String username, @RequestParam("password")String password) {
	if(username.equals("shafeeq") && password.equals("shafeeq123")) {
		return "main";
	}
	return "redirect:/";
	
}

}
