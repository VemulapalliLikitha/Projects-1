package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cap.model.Student;
import com.cap.service.StudentService;

@Controller
public class StudController {
	
	@Autowired
	private StudentService studentService;
	
	@RequestMapping("/hello world!!")
	public List<Student> getStudentPage(ModelMap map) {
		List<Student> studs=studentService.getStudent();
		return studs;
		
	}
}
