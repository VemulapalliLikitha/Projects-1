package org.cap.service;


import org.cap.dao.WalletDao;
import org.cap.model.CustomerLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("loginService")
public class WalletServiceImpl implements WalletService {
	@Autowired
	private WalletDao walletDao;
	
	@Override
	public boolean validateLogin(int customerId, String custPwd) {
		
		return walletDao.validateLogin(customerId, custPwd);
	}

	@Override
	public String getCustomerName(int customerId) {
		
		return walletDao.getCustomerName(customerId);
	}

	@Override
	public CustomerLogin findCustomer(int customerId) {
		
		return walletDao.findCustomer(customerId);
	}

}
