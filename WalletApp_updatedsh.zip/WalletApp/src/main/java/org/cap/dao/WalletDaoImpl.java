package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Transactional
@Repository("walletDao")
public class WalletDaoImpl implements WalletDao{
@PersistenceContext
private EntityManager entityManager;
	/*@Override
	public Customer getLogin(String uname,Integer password) {
		// TODO Auto-generated method stub
		Query l= entityManager.createQuery("select c from Customer c where c.firstName=:uname and c.customerId=:pass");
        l.setParameter("uname", uname);
        l.setParameter("pass", password);
		Customer m=(Customer) l.getSingleResult();
        System.out.println(m);
         
         
         
		return m;
	}*/


/*
	@Override
	public void saveAccount(Account acc) {
		// TODO Auto-generated method stub
		entityManager.persist(acc);
	}*/
	@Override
	public List<Customer> getLogin(Integer id,String Password) {
		// TODO Auto-generated method stub
	Query query=entityManager.createQuery("from Customer where customerId=? and customerPwd=?");
	   query.setParameter(0, id);
	   query.setParameter(1, Password);
	   List<Customer> c=query.getResultList();
		return c;
	}
	
	/*public List<Account> getAllAccount(Integer id)
	{
		
		Query l=entityManager.createQuery("select a from Account a where a.accountType=:uname");
	    l.setParameter("uname", "rd");
	    List<Account> account=l.getResultList();
	    return account;
  	}*/
	/*@Override
	public Account find(Integer id) {
		// TODO Auto-generated method stub
		Account a=entityManager.find(Account.class, id);
		return a;
	}*/
	@Override
	public String getCustomerName(Integer id) {
		// TODO Auto-generated method stub
		Query query=entityManager.createQuery("select firstName from Customer where customerId=?");
		   query.setParameter(0, id);
		   
		   List<String> c=query.getResultList();
			return c.get(0);
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		
			Customer customer= entityManager.find(Customer.class, customerId);
			
			
			return customer;
		
	}
	
	

}
