package org.cap.dao;

public interface WalletDao {

}
