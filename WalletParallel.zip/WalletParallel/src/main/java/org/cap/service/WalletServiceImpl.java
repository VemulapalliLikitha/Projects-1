package org.cap.service;

public class WalletServiceImpl implements WalletService {

}
