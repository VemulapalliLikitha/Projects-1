package org.cap.service;

import org.cap.model.CustomerLogin;

public interface WalletService {

	public boolean validateLogin(int custId, String custPwd);

	public String getCustomerName(int customerId);

	public CustomerLogin findCustomer(int customerId);

}
