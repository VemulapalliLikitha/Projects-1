package org.cap.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.cap.model.Account;
import org.cap.model.CustTransaction;

public interface AccDao {
	public void createAccount(Account account);//
	public List<Account> getAllAccounts(int customerId);//
	public Map<Account, Double> getAmoutCrDe(String strQuery,int customerId);//
	
	public Account findAccount(long accNo);//
	public void addTransaction(CustTransaction transaction1);//
	
	//public void createTransactionAccount(CustTransaction transaction);
	public List<Account> getAllToAccounts(Integer customerId);//
	
	public List<CustTransaction> getTransactions(int customerId);//
	public Account getAccount(long accNo);//
	public Account getAccount1(long accNo1);//
	public void fundTransfer(CustTransaction transaction);//
	public List<CustTransaction> getDatedTransactions(Integer id, Date d1, Date d2); 

}
