package org.cap.loginRest.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
 private String emailId;
 private String password;
 
 public Customer() {
	 
 }
public Customer(String emailId, String password) {
	super();
	this.emailId = emailId;
	this.password = password;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "Customer [emailId=" + emailId + ", password=" + password + "]";
}
 

}
