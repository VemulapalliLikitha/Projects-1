package com.cap.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cap.model.Student;
@Service("studentService")
public class StudentServiceIMPL implements StudentService{
	@Autowired
	private StudentDAO studentDao;

	public List<Student> getStudent() {
		
		return studentDao.getStudent();
	}



	
	}

	
