package org.cap.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
@Entity
public class Account {
@Id
@GeneratedValue

private int accountId;
private long accountNo;
private String accountType;
private double openingBalance;
private Date openingDate;
private int customerId;
private String accountStatus;


@OneToMany(mappedBy="transactionId")
private Transaction transaction;


public Account(int accountId, long accountNo, String accountType, double openingBalance, Date openingDate,
		int customerId, String accountStatus) {
	super();
	this.accountId = accountId;
	this.accountNo = accountNo;
	this.accountType = accountType;
	this.openingBalance = openingBalance;
	this.openingDate = openingDate;
	this.customerId = customerId;
	this.accountStatus = accountStatus;
}
public Account() {
}
@Override
public String toString() {
	return "Account [accountId=" + accountId + ", accountNo=" + accountNo + ", accountType=" + accountType
			+ ", openingBalance=" + openingBalance + ", openingDate=" + openingDate + ", customerId=" + customerId
			+ ", status=" + accountStatus + "]";
}
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}
public double getOpeningBalance() {
	return openingBalance;
}
public void setOpeningBalance(double openingBalance) {
	this.openingBalance = openingBalance;
}
public Date getOpeningDate() {
	return openingDate;
}
public void setOpeningDate(Date openingDate) {
	this.openingDate = openingDate;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getAccountStatus() {
	return accountStatus;
}
public void setAccountStatus(String status) {
	this.accountStatus = status;
}


}
