package com.cap.service;

import java.util.List;

import com.cap.mode.Pilot;

public interface PilotService {

	public void save(Pilot pilot);
	public List<Pilot>getAll();
	public void delete(Integer pilotId);
} 
 
