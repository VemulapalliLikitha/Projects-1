package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("pilotDao")

public class PilotDaoImpl implements PilotDao {
	
	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	@Override
	public void save(Pilot pilot) {
		em.persist(pilot);
	}

	@Transactional(readOnly=true)
	@Override
	public List<Pilot> getAll() {
		List<Pilot> pilots = em.createQuery("from Pilot").getResultList();
		return pilots;
	}
	
	
	@Override
	@Transactional
	public void delete(Integer pilotId) {
		Pilot pilot= em.find(Pilot.class, pilotId);
		em.remove(pilot);
	}

}
