package com.cap.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cap.dao.StudentDAO;
import com.cap.model.Student;
@Repository("StudentDAO")
public class StudentDAOimpl implements StudentDAO{

	
		@PersistenceContext
		private EntityManager em;
		public List<Student> getStudents() {
		em.persist();
		
		
	}

}
