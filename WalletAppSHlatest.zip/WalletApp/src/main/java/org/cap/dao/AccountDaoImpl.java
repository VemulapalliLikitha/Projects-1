package org.cap.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
@Transactional
@Repository("accountDao")
public class AccountDaoImpl implements AccountDao{
	    @PersistenceContext(type=PersistenceContextType.EXTENDED)
		private EntityManager entityManager;
	    @Transactional
		@Override
		public void createAccount(Account account) {
			
			Query query= entityManager.createQuery("select max(accountNo) from Account");
			
			List<Long> max= query.getResultList();
			
			account.setAccountNo(max.get(0)+1);
			
			System.out.println(account);
			
			entityManager.persist(account);
			
		}

		@Override
		@Transactional(readOnly=true)
		public List<Account> getAllAccount(Integer id) {
			Query query= entityManager
					.createQuery("from Account acc where acc.customer.customerId=:customId");
				
				query.setParameter("customId", id);
				
				
				List<Account> accounts= query.getResultList();
				for (Account account : accounts) {
					System.out.println(account);
				}
				
				
				return accounts;
		}

		@Override
		@Transactional(readOnly=true)
		public Map<Account, Double> getAmoutCrDe(String strQuery, int customerId) {
			Query query2=entityManager
					.createQuery(strQuery);
			
			query2.setParameter("custId", customerId);
			
			List<Transaction> transactions=query2.getResultList();
			Map<Account, Double> map=
					transactions.stream()
							.collect(
							Collectors.groupingBy(Transaction::getFromAccount,
								Collectors.summingDouble(Transaction::getAmount))
							);
					return map;
		}
		
		
		
		 @Transactional
			@Override
			public void createTransactionAccount(Transaction account) {
				
				//Query query= entityManager.createQuery("select max(accountNo) from Account");
				
			//	List<Long> max= query.getResultList();
				
				//account.setAccountNo(max.get(0)+1);
				
				//System.out.println(account);
			 System.out.println("Transaction complete............");
				entityManager.persist(account);
				
			}

		@Override
		public List<Transaction> getTransactions(Integer id) {
			// TODO Auto-generated method stub
			
			Query query= entityManager.createQuery("from Transaction tx where tx.customer.customerId=:cust");
			query.setParameter("cust", id);
				List<Transaction> transaction= query.getResultList();
			
			
			
			return transaction;
		}

		@Override
		public Account findAccount(long accountNo) {
			// TODO Auto-generated method stub
			Query query= entityManager.createQuery("from Account where accountNo=:accno");
			query.setParameter("accno", accountNo);
			List<Account> accounts= query.getResultList();
			return accounts.get(0);
		}

		@Override
		public List<Account> getOtherAccount(Integer id) {
			// TODO Auto-generated method stub
			Query query=entityManager.createQuery("from Account acc where acc.customer.customerId!=:customId");
			query.setParameter("customId", id);
			
			
			List<Account> accounts= query.getResultList();
			for (Account account : accounts) {
				System.out.println(account);
			}
			
			
			return accounts;
		}

		@Override
		public List<Transaction> getDatedTransactions(Integer id, Date d1, Date d2) {
			// TODO Auto-generated method stub
			
			Query query= entityManager.createQuery("from Transaction tx where tx.customer.customerId=? and transactionDate between ? and ?");
			query.setParameter(0, id);
			query.setParameter(1,d1);
			query.setParameter(2,d2);
			
			List<Transaction> accounts= query.getResultList();
			for (Transaction account : accounts) {
				System.out.println(account);
			}
			
			
			return accounts;
			
			
		}

		
		
		
		

		
	}


