package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;


import org.cap.modal.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("PilotDao")
@Transactional
public class PilotDaoImpl implements PilotDao {

	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void save(Pilot pilot) {
		entityManager.persist(pilot);
	}
@Transactional(readOnly=true)
	@Override
	public List<Pilot> getall() {
		List<Pilot> pilots=entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}
@Override
public void delete(Integer pilotId) {
	Pilot pilot=entityManager.find(Pilot.class, pilotId);
	entityManager.remove(pilot);
	
}
@Override
@Transactional
public void update(Pilot pilot) {
	if(pilot.getpilotId()!=0)
		entityManager.merge(pilot);
	else
		entityManager.persist(pilot);
	
}
@Override
@Transactional
public Pilot findPilot(Integer pilotId) {
	
	Pilot pilot=entityManager.find(Pilot.class,pilotId );
	return pilot;
}
}
