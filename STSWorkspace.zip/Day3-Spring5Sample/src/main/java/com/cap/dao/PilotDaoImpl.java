package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cap.mode.Pilot;


@Repository("pilotDao")
@Transactional
public class PilotDaoImpl implements PilotDao{

@PersistenceContext
private EntityManager em;
@Override
public void save(com.cap.mode.Pilot pilot) {
	
	em.persist(pilot);
}


@org.springframework.transaction.annotation.Transactional(readOnly=true)
@Override
public List<Pilot> getAll(){
	List<Pilot>pilots=em.createQuery("from Pilot").getResultList();
	return pilots;
	}

@Transactional
@Override
public void delete(Integer pilotId) {
		Pilot pilot= em.find(Pilot.class, pilotId);
		em.remove(pilot);
	}
}
