package com.cap.mode;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
@Entity
public class Pilot {
	@Id
	@GeneratedValue
	private int pilotId;
	@NotEmpty(message="Please Enter First name")
	private String firstName;
	private String lastName;
	@Past(message="*Please Enter Past Date")
	private Date dateOfBirth;
	@Future(message="*Please Enter Future Date")
	private Date dateOfJoin;
	private boolean isCertified;
	private double salary;
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", dateOfJoin=" + dateOfJoin + ", isCertified=" + isCertified + ", salary=" + salary + "]";
	}
	public Pilot() {
		super();
	}
	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoin,
			boolean isCertified, double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.isCertified = isCertified;
		this.salary = salary;
	}
	
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfJoin() {
		return dateOfJoin;
	}
	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	public boolean getIsCertified() {
		return isCertified;
	}
	public void setIsCertified(boolean isCertified) {
		this.isCertified = isCertified;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	
}
