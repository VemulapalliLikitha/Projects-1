package org.cap.controller;

import java.util.ArrayList;
import java.util.List;

import org.cap.model.Student;
import org.cap.service.IStudentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
	@Autowired
	private IStudentService studentService ;
	private Student student;
	@RequestMapping("/")
public String getStudentPage(ModelMap map) {
		List<Student> students=studentService.getStudents();
		List<String> locations=new ArrayList<>();
		locations.add("Hyderabad");
		locations.add("Pune");
		locations.add("chennai");
		locations.add("Bangalore");
		map.put("locations", locations);
		map.put("studs", students);
		if(student!=null)
			map.put("student", student);
		else
			map.put("student", new Student());
		return "student";

}
	@RequestMapping("/update/{studId}")
	public String updateStudent(@PathVariable("studId") Integer studId) {
		 student=studentService.findstudent(studId);
		return "redirect:/";	
	}
	@RequestMapping("/updateStudent")
	public String  updateStudent(@ModelAttribute("student") Student student1) {
		if(student1!=null) {
			studentService.update(student1);
			student=null;
		}
		
		return "redirect:/";
		
	}
	
}
