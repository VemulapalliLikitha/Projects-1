package com.cg.walletjdbc.dao;

import com.cg.walletjdbc.bean.Customer;
import com.cg.walletjdbc.bean.Transactions;
import com.cg.walletjdbc.exception.WalletException;

public interface WalletDao {

	public int createAccount(Customer customer) throws WalletException;
	public int assignAccount(String type,double initbalance) throws WalletException;
	public double showBalance(int accno) throws WalletException;
	public double deposit(int accno, double amount) throws WalletException;
	public double withdraw(int accno, double amount) throws WalletException;
	public int fundTransfer(int faccno,int taccno, double amount) throws WalletException;
	public void printTransactions(int accno) throws WalletException;
	
}
