package com.cap.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cap.mode.Pilot;

@Repository
public interface PilotDao {
	public void save(Pilot pilot);

	public List<Pilot> getAll();
	public void delete(Integer pilotId);
}
